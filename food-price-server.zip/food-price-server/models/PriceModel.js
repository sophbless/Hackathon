const mongoose = require("mongoose");

const priceSchema = new mongoose.Schema({
    commodity: String,
    price: Number,
    currency: { type: String, default: "₹" }, 
    date: Date
});

module.exports = mongoose.model("Price", priceSchema);
