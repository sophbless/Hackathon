const Price = require("../models/PriceModel");


exports.getPrices = async (req, res) => {
    try {
        const prices = await Price.find();
        res.json(prices);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.addPrice = async (req, res) => {
    const { commodity, price, date } = req.body;
    try {
        const newPrice = new Price({ commodity, price, date });
        await newPrice.save();
        res.status(201).json(newPrice);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};
