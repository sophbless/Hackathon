const express = require("express");
const Price = require("../models/PriceModel");

const router = express.Router();

// Get all prices
router.get("/prices", async (req, res) => {
    try {
        const prices = await Price.find();
        res.json(prices);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a new price entry
router.post("/prices", async (req, res) => {
    try {
        const price = new Price({
            commodity: req.body.commodity,
            price: req.body.price,
            currency: "₹", 
            date: req.body.date,
        });

        const newPrice = await price.save();
        res.status(201).json(newPrice);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});
// Delete a price entry
router.delete("/prices/:id", async (req, res) => {
    try {
        await Price.findByIdAndDelete(req.params.id);
        res.json({ message: "Price deleted successfully" });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;
